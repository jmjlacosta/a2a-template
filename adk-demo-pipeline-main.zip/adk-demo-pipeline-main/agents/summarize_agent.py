"""
LLM Summarize Agent - Analyzes and summarizes medical text chunks.
Following nutrition_example.py pattern with Google ADK.
"""
import os
import json
import logging
from typing import List, Dict, Any
from dotenv import load_dotenv

# Base class import
from shared.base_agent import BaseLLMAgentExecutor

# Tool imports
from tools.summarize_tools import SUMMARIZE_TOOLS

# A2A imports for building the app
from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import AgentCard, AgentProvider, AgentCapabilities, AgentSkill
import uvicorn

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


class LLMSummarizeAgentExecutor(BaseLLMAgentExecutor):
    """LLM-powered medical text summarization agent."""
    
    def get_agent_name(self) -> str:
        """Return the agent's name."""
        return "Medical Summarizer"
    
    def get_system_instruction(self) -> str:
        """Return the system instruction for medical summarization."""
        return """You are a medical document summarization specialist. Your role is to analyze medical text chunks and create accurate, clinically relevant summaries.

Core responsibilities:
1. Summarize medical text with appropriate detail level
2. Extract key medical entities (diagnoses, treatments, medications)
3. Score relevance based on medical importance
4. Generate clinical summaries from multiple sources
5. Analyze medical terminology

When summarizing medical text:
- Prioritize clinically actionable information
- Maintain medical accuracy and precision
- Preserve critical details (dosages, dates, values)
- Use appropriate medical terminology
- Highlight abnormal findings or critical results

For entity extraction:
- Diagnoses: Include ICD codes, staging, severity
- Medications: Drug name, dose, route, frequency
- Procedures: Type, date, findings, complications
- Lab results: Value, reference range, significance
- Symptoms: Onset, duration, severity, associated factors

Relevance scoring (0-10):
- Consider medical importance over text length
- Weight primary diagnoses and active treatments highly
- Factor in temporal relevance (current vs past)
- Account for pattern match quality
- Prioritize abnormal or critical findings

Summary styles:
- Concise: 2-3 sentences with key findings
- Detailed: Comprehensive paragraph with context
- Clinical: Structured format focusing on diagnoses/treatments
- Bullet: Key points in digestible format

Quality guidelines:
- Never invent or assume medical information
- Flag inconsistencies or contradictions
- Note when information is incomplete
- Maintain patient safety focus
- Use standard medical abbreviations appropriately

For batch processing:
- Identify relationships between chunks
- Combine related information logically
- Avoid redundancy while maintaining completeness
- Create coherent narrative from fragments

Always aim to produce summaries that would be useful for clinical decision-making."""
    
    def get_tools(self) -> List[Any]:
        """Return the summarization tools."""
        return SUMMARIZE_TOOLS




# Load environment at module level
load_dotenv()

# Create enhanced agent card for LLM-powered summarize agent
logger.info("🚀 Starting LLM Summarize Agent...")
logger.info("📋 Creating enhanced agent card for LLM-powered summarize agent...")

agent_card = AgentCard(
    name="Medical Summarizer",
    description="LLM-powered agent that analyzes medical text chunks to create summaries, extract entities, score relevance, and generate clinical overviews.",
    version="2.0.0",
    url=os.getenv("HU_APP_URL") or "http://localhost:8003",
    capabilities=AgentCapabilities(
        streaming=True, push_notifications=False, state_transition_history=True
    ),
    skills=[
            AgentSkill(
                id="summarize_medical_chunk",
                name="Summarize Medical Chunk",
                description="Create concise summaries of medical text with key points and entity extraction.",
                tags=["summarization", "medical", "llm", "text-analysis", "entity-extraction"],
                examples=[
                    "Summarize diagnosis section from medical record",
                    "Extract key points from treatment plan",
                    "Score chunk relevance for cancer-related content",
                    "Identify medications and dosages in text",
                    "Summarize pathology report findings"
                ],
                input_modes=["application/json", "text/plain"],
                output_modes=["application/json", "text/plain"]
            ),
            AgentSkill(
                id="extract_medical_entities",
                name="Extract Medical Entities",
                description="Extract specific medical entities from text chunks.",
                tags=["entity-extraction", "medical", "llm", "nlp"],
                examples=[
                    "Extract all diagnoses from chunk",
                    "Identify medications with dosages",
                    "Find treatment procedures mentioned",
                    "Extract laboratory results",
                    "Identify symptoms and complaints"
                ],
                input_modes=["application/json", "text/plain"],
                output_modes=["application/json", "text/plain"]
            ),
            AgentSkill(
                id="score_medical_relevance",
                name="Score Medical Relevance",
                description="Score text chunks based on medical importance and search relevance.",
                tags=["scoring", "relevance", "medical", "llm"],
                examples=[
                    "Score chunk for diagnostic importance",
                    "Rate relevance to cancer treatment",
                    "Evaluate medical information density",
                    "Score based on pattern match quality",
                    "Rank chunks by clinical significance"
                ],
                input_modes=["application/json", "text/plain"],
                output_modes=["application/json", "text/plain"]
            ),
            AgentSkill(
                id="batch_summarize_chunks",
                name="Batch Summarize Chunks",
                description="Efficiently summarize multiple chunks with relationship detection.",
                tags=["batch-processing", "summarization", "medical", "llm"],
                examples=[
                    "Summarize all diagnosis-related chunks",
                    "Process multiple treatment sections",
                    "Combine related lab results",
                    "Create overview from chunk collection"
                ],
                input_modes=["application/json", "text/plain"],
                output_modes=["application/json", "text/plain"]
            ),
            AgentSkill(
                id="generate_clinical_summary",
                name="Generate Clinical Summary",
                description="Create comprehensive clinical summary from multiple sources.",
                tags=["clinical-summary", "synthesis", "medical", "llm"],
                examples=[
                    "Generate patient care summary",
                    "Create treatment overview",
                    "Synthesize multiple visit notes",
                    "Compile diagnostic journey"
                ],
                input_modes=["application/json", "text/plain"],
                output_modes=["application/json", "text/plain"]
            ),
            AgentSkill(
                id="analyze_medical_terminology",
                name="Analyze Medical Terminology",
                description="Extract and categorize medical terms with optional definitions.",
                tags=["terminology", "medical", "analysis", "llm"],
                examples=[
                    "Identify all medical abbreviations",
                    "Extract drug names and classes",
                    "Find anatomical terms",
                    "Categorize medical procedures"
                ],
                input_modes=["application/json", "text/plain"],
                output_modes=["application/json", "text/plain"]
            )
        ],
    default_input_modes=["application/json", "text/plain"],
    default_output_modes=["application/json", "text/plain"],
    provider=AgentProvider(
        organization="ADK Pipeline V2",
        url="https://github.com/Health-Universe/adk-demo-pipeline"
    )
)
logger.info("✅ Agent card created successfully")

# Create the A2A application components
logger.info("🏗️ Building A2A application components...")

logger.info("🤖 Creating LLM Summarize Agent Executor...")
agent_executor = LLMSummarizeAgentExecutor()
logger.info("✅ Agent executor created successfully")
logger.info(f"🔧 Available tools: {[tool.name for tool in agent_executor.get_tools()]}")

logger.info("📋 Creating task store (In-Memory)...")
task_store = InMemoryTaskStore()
logger.info("✅ Task store initialized")

logger.info("🔄 Creating default request handler...")
request_handler = DefaultRequestHandler(
    agent_executor=agent_executor,
    task_store=task_store,
)
logger.info("✅ Request handler configured")

logger.info("🌐 Building A2A Starlette application...")
logger.info(f"📋 Agent card: {agent_card.name}")
logger.info(f"🎯 Skills available: {len(agent_card.skills)}")

app = A2AStarletteApplication(
    agent_card=agent_card, http_handler=request_handler
).build()

logger.info("✅ A2A Starlette application built successfully")
logger.info("🎯 Application ready for deployment")


if __name__ == "__main__":
    host = "0.0.0.0"
    port = int(os.getenv("AGENT_PORT", "8003"))
    
    logger.info(f"🌐 Starting Summarize Agent server on {host}:{port}")
    logger.info(f"📍 Agent URL: {os.getenv('HU_APP_URL', f'http://localhost:{port}')}")
    
    uvicorn.run(
        app,
        host=host,
        port=port,
        log_level="info"
    )