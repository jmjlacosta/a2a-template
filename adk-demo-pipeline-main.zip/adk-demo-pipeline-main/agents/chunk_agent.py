"""
LLM Chunk Agent - Extracts intelligent context chunks from documents.
Following nutrition_example.py pattern with Google ADK.
"""
import os
import json
import logging
from typing import List, Dict, Any
from dotenv import load_dotenv

# Base class import
from shared.base_agent import BaseLLMAgentExecutor

# Tool imports
from tools.chunk_tools import CHUNK_TOOLS

# A2A imports for building the app
from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import AgentCard, AgentProvider, AgentCapabilities, AgentSkill
import uvicorn

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


class LLMChunkAgentExecutor(BaseLLMAgentExecutor):
    """LLM-powered chunk extraction agent with intelligent boundary detection."""
    
    def get_agent_name(self) -> str:
        """Return the agent's name."""
        return "Context Extractor"
    
    def get_system_instruction(self) -> str:
        """Return the system instruction for chunk extraction."""
        return """You are a medical document context extraction specialist. Your role is to create meaningful chunks of text around search matches using intelligent boundary detection.

IMPORTANT: File Content Handling
When you receive match_info that includes 'file_content':
- Always pass the 'file_content' parameter to chunk extraction functions
- The functions will use the provided content instead of reading from the file system
- This allows processing content from S3 or other external sources

Example: If match_info contains {"file_path": "doc.txt", "file_content": "...content...", ...},
call create_document_chunk(file_path="doc.txt", match_info={...}, file_content="...content...")

When extracting chunks, you should:
1. Identify natural document boundaries (sections, paragraphs, lists)
2. Preserve complete semantic units of information
3. Include sufficient context for understanding
4. Merge overlapping chunks when appropriate
5. Optimize chunk size while maintaining coherence

Key principles:
- Respect document structure and formatting
- Never break in the middle of sentences or important concepts
- Expand to include complete medical findings or assessments
- Consider the relationship between adjacent sections
- Preserve headers and their associated content together

Boundary detection guidelines:
- Section headers indicate major boundaries
- Empty lines often mark paragraph boundaries
- List items should be kept together when related
- Clinical findings should include their full context
- Temporal information should stay with related events

For medical documents specifically:
- Keep diagnosis statements with supporting evidence
- Include full medication entries (name, dose, frequency)
- Preserve complete laboratory or imaging results
- Maintain procedure descriptions with outcomes
- Keep assessment and plan sections intact

Chunk optimization:
- Target readable chunk sizes (10-50 lines typical)
- Prioritize completeness over strict size limits
- Remove redundant information when merging chunks
- Preserve the most clinically relevant content

Always aim to create chunks that can stand alone as meaningful units of medical information."""
    
    def get_tools(self) -> List[Any]:
        """Return the chunk extraction tools."""
        return CHUNK_TOOLS




# Load environment at module level
load_dotenv()

# Create enhanced agent card for LLM-powered chunk agent
logger.info("🚀 Starting LLM Chunk Agent...")
logger.info("📋 Creating enhanced agent card for LLM-powered chunk agent...")

agent_card = AgentCard(
    name="Context Extractor",
    description="LLM-powered agent that extracts semantic chunks from documents with intelligent boundary detection and context preservation.",
    version="2.0.0",
    url=os.getenv("HU_APP_URL") or "http://localhost:8003",
    capabilities=AgentCapabilities(
        streaming=True, push_notifications=False, state_transition_history=True
    ),
    skills=[
            AgentSkill(
                id="create_document_chunk",
                name="Create Document Chunk",
                description="Extract semantic chunks around pattern matches with intelligent boundaries.",
                tags=["chunk", "extraction", "document-processing", "medical", "text-processing"],
                examples=[
                    "Create a chunk around line 45 with pattern match",
                    "Extract context around diagnosis mention at line 120",
                    "Get semantic chunk for medication reference",
                    "Create chunk with natural paragraph boundaries",
                    "Extract section containing matched keyword"
                ],
                input_modes=["application/json", "text/plain"],
                output_modes=["application/json", "text/plain"]
            ),
            AgentSkill(
                id="extract_multiple_chunks",
                name="Extract Multiple Chunks",
                description="Extract multiple chunks from document matches with optional merging.",
                tags=["chunk", "batch-processing", "medical"],
                examples=[
                    "Extract chunks for all diagnosis mentions",
                    "Create chunks from multiple search results",
                    "Merge overlapping chunks for efficiency",
                    "Process batch of pattern matches"
                ],
                input_modes=["application/json", "text/plain"],
                output_modes=["application/json", "text/plain"]
            ),
            AgentSkill(
                id="find_chunk_boundaries",
                name="Find Chunk Boundaries",
                description="Identify natural boundaries for intelligent chunk extraction.",
                tags=["boundary-detection", "semantic", "medical"],
                examples=[
                    "Find section boundaries around match",
                    "Identify paragraph breaks for chunking",
                    "Detect list boundaries",
                    "Locate header-based sections"
                ],
                input_modes=["application/json", "text/plain"],
                output_modes=["application/json", "text/plain"]
            ),
            AgentSkill(
                id="optimize_chunk_size",
                name="Optimize Chunk Size",
                description="Optimize chunk size while preserving important medical context.",
                tags=["optimization", "context-preservation", "medical"],
                examples=[
                    "Reduce chunk to target size",
                    "Preserve key medical information",
                    "Remove redundant content",
                    "Balance size and completeness"
                ],
                input_modes=["application/json", "text/plain"],
                output_modes=["application/json", "text/plain"]
            )
        ],
    default_input_modes=["application/json", "text/plain"],
    default_output_modes=["application/json", "text/plain"],
    provider=AgentProvider(
        organization="ADK Pipeline V2",
        url="https://github.com/Health-Universe/adk-demo-pipeline"
    )
)
logger.info("✅ Agent card created successfully")

# Create the A2A application components
logger.info("🏗️ Building A2A application components...")

logger.info("🤖 Creating LLM Chunk Agent Executor...")
agent_executor = LLMChunkAgentExecutor()
logger.info("✅ Agent executor created successfully")
logger.info(f"🔧 Available tools: {[tool.name for tool in agent_executor.get_tools()]}")

logger.info("📋 Creating task store (In-Memory)...")
task_store = InMemoryTaskStore()
logger.info("✅ Task store initialized")

logger.info("🔄 Creating default request handler...")
request_handler = DefaultRequestHandler(
    agent_executor=agent_executor,
    task_store=task_store,
)
logger.info("✅ Request handler configured")

logger.info("🌐 Building A2A Starlette application...")
logger.info(f"📋 Agent card: {agent_card.name}")
logger.info(f"🎯 Skills available: {len(agent_card.skills)}")

app = A2AStarletteApplication(
    agent_card=agent_card, http_handler=request_handler
).build()

logger.info("✅ A2A Starlette application built successfully")
logger.info("🎯 Application ready for deployment")


if __name__ == "__main__":
    host = "0.0.0.0"
    port = int(os.getenv("AGENT_PORT", "8003"))
    
    logger.info(f"🌐 Starting Chunk Agent server on {host}:{port}")
    logger.info(f"📍 Agent URL: {os.getenv('HU_APP_URL', f'http://localhost:{port}')}")
    
    uvicorn.run(
        app,
        host=host,
        port=port,
        log_level="info"
    )