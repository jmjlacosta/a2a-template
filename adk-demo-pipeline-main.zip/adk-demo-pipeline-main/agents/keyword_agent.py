"""
LLM Keyword Agent - Generates regex patterns from document previews.
Following nutrition_example.py pattern with Google ADK.
"""
import os
import json
import logging
from typing import List, Dict, Any
from dotenv import load_dotenv

# Base class import
from shared.base_agent import BaseLLMAgentExecutor

# Tool imports
from tools.keyword_tools import KEYWORD_TOOLS

# A2A imports for building the app
from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import AgentCard, AgentProvider, AgentCapabilities, AgentSkill
import uvicorn

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


class LLMKeywordAgentExecutor(BaseLLMAgentExecutor):
    """LLM-powered keyword pattern generator following nutrition_example.py pattern."""
    
    def get_agent_name(self) -> str:
        """Return the agent's name."""
        return "Keyword Pattern Generator"
    
    def get_system_instruction(self) -> str:
        """Return the system instruction for pattern generation."""
        return """You are a medical document pattern generator. Your role is to analyze medical document previews and generate regex patterns that can identify important information.

When given a document preview, you should:
1. Identify the document structure and format
2. Recognize medical terminology and abbreviations
3. Generate regex patterns that match:
   - Section headers and boundaries
   - Clinical findings and events
   - Medical terms and their variations
   - Temporal markers and dates

Guidelines for pattern generation:
- Use ripgrep-compatible regex syntax
- Include case-insensitive flags (?i) where appropriate
- Create patterns specific enough to avoid false positives
- Include both abbreviated and full forms of medical terms
- Consider different formatting styles (structured vs narrative)

Return patterns organized by category:
- section_patterns: Headers and document structure
- clinical_patterns: Medical findings and events
- term_patterns: Medical terminology
- temporal_patterns: Dates and time references

Each pattern should include:
- pattern: The regex pattern string
- priority: high/medium/low based on importance
- description: What the pattern matches

Always validate patterns for regex syntax correctness before returning them."""
    
    def get_tools(self) -> List[Any]:
        """Return the keyword generation tools."""
        return KEYWORD_TOOLS




# Load environment at module level
load_dotenv()

# Create enhanced agent card for LLM-powered keyword agent
logger.info("🚀 Starting LLM Keyword Agent...")
logger.info("📋 Creating enhanced agent card for LLM-powered keyword agent...")

agent_card = AgentCard(
    name="Keyword Pattern Generator",
    description="LLM-powered agent that analyzes medical document previews and generates regex patterns for identifying key information.",
    version="2.0.0",
    url=os.getenv("HU_APP_URL") or "http://localhost:8003",
    capabilities=AgentCapabilities(
        streaming=True, push_notifications=False, state_transition_history=True
    ),
    skills=[
        AgentSkill(
            id="generate_document_patterns",
            name="Generate Document Patterns",
            description="Analyze document preview and generate regex patterns to identify key sections, clinical terms, and relevant information.",
            tags=["pattern-generation", "regex", "medical", "llm", "document-analysis"],
            examples=[
                "Generate patterns from medical record preview",
                "Create regex patterns for oncology report",
                "Extract section headers from pathology document",
                "Identify temporal markers in clinical notes",
                "Generate patterns focusing on diagnosis and treatment"
            ],
            input_modes=["application/json", "text/plain"],
            output_modes=["application/json", "text/plain"]
        ),
        AgentSkill(
            id="generate_focused_patterns",
            name="Generate Focused Patterns",
            description="Generate patterns with specific focus areas like diagnosis, medications, or procedures.",
            tags=["pattern-generation", "focused", "medical", "llm"],
            examples=[
                "Generate patterns focusing on medications only",
                "Create patterns for surgical procedures",
                "Extract patterns for laboratory results",
                "Focus on diagnosis and staging information"
            ],
            input_modes=["application/json", "text/plain"],
            output_modes=["application/json", "text/plain"]
        ),
        AgentSkill(
            id="analyze_preview_structure",
            name="Analyze Document Structure",
            description="Analyze document structure to identify formatting patterns and organization.",
            tags=["structure-analysis", "document", "medical"],
            examples=[
                "Analyze document formatting",
                "Identify section organization",
                "Detect structured vs narrative content"
            ],
            input_modes=["application/json", "text/plain"],
            output_modes=["application/json", "text/plain"]
        )
    ],
    default_input_modes=["application/json", "text/plain"],
    default_output_modes=["application/json", "text/plain"],
    provider=AgentProvider(
        organization="ADK Pipeline V2",
        url="https://github.com/Health-Universe/adk-demo-pipeline"
    )
)
logger.info("✅ Agent card created successfully")

# Create the A2A application components
logger.info("🏗️ Building A2A application components...")

logger.info("🤖 Creating LLM Keyword Agent Executor...")
agent_executor = LLMKeywordAgentExecutor()
logger.info("✅ Agent executor created successfully")
logger.info(f"🔧 Available tools: {[tool.name for tool in agent_executor.get_tools()]}")

logger.info("📋 Creating task store (In-Memory)...")
task_store = InMemoryTaskStore()
logger.info("✅ Task store initialized")

logger.info("🔄 Creating default request handler...")
request_handler = DefaultRequestHandler(
    agent_executor=agent_executor,
    task_store=task_store,
)
logger.info("✅ Request handler configured")

logger.info("🌐 Building A2A Starlette application...")
logger.info(f"📋 Agent card: {agent_card.name}")
logger.info(f"🎯 Skills available: {len(agent_card.skills)}")

app = A2AStarletteApplication(
    agent_card=agent_card, http_handler=request_handler
).build()

logger.info("✅ A2A Starlette application built successfully")
logger.info("🎯 Application ready for deployment")


if __name__ == "__main__":
    host = "0.0.0.0"
    port = int(os.getenv("AGENT_PORT", "8003"))
    
    logger.info(f"🌐 Starting Keyword Agent server on {host}:{port}")
    logger.info(f"📍 Agent URL: {os.getenv('HU_APP_URL', f'http://localhost:{port}')}")
    
    uvicorn.run(
        app,
        host=host,
        port=port,
        log_level="info"
    )