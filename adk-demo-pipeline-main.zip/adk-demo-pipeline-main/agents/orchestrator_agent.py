"""
LLM Orchestrator Agent - Coordinates the document processing pipeline.
Following nutrition_example.py pattern with Google ADK.
"""
import os
import json
import logging
import asyncio
from datetime import datetime
from typing import List, Dict, Any, Optional
from dotenv import load_dotenv

# Base class import
from shared.base_agent import BaseLLMAgentExecutor
# A2A client for standard agent communication
from shared.a2a_client import A2AAgentClient

# Tool imports
from tools.orchestrator_tools import ORCHESTRATOR_TOOLS

# A2A imports for building the app
from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore, TaskUpdater
from a2a.types import AgentCard, AgentProvider, AgentCapabilities, AgentSkill, TaskState, Part, TextPart
from a2a.utils import new_task, new_agent_text_message
from a2a.server.agent_execution import RequestContext
from a2a.server.events import EventQueue
import uvicorn

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


class LLMOrchestratorAgentExecutor(BaseLLMAgentExecutor):
    """LLM-powered orchestrator for the medical document analysis pipeline."""
    
    def __init__(self):
        super().__init__()
        # Load agent configuration
        self.agent_config = self._load_agent_config()
        self.a2a_client = None
        
    def get_agent_name(self) -> str:
        """Return the agent's name."""
        return "Pipeline Orchestrator"
    
    def get_system_instruction(self) -> str:
        """Return the system instruction for orchestration."""
        return """You are the orchestrator of a medical document analysis pipeline. Your role is to understand user requests and synthesize results from the pipeline execution.

Your responsibilities:
1. Understand natural language requests from users
2. Plan the optimal analysis strategy
3. Synthesize results from the pipeline into coherent responses
4. Handle errors gracefully with recovery strategies

The orchestrator will automatically execute the pipeline for you by:
- Calling the Keyword Agent to generate search patterns
- Using the Grep Agent to search for those patterns
- Extracting context with the Chunk Agent
- Analyzing with the Summarize Agent

Your tools help you:
- **understand_user_request**: Parse and understand what the user wants
- **plan_pipeline_execution**: Plan the analysis approach (focus areas, pattern types)
- **synthesize_final_response**: Combine pipeline results into a comprehensive response
- **handle_pipeline_errors**: Develop recovery strategies for errors
- **optimize_pipeline_performance**: Learn from execution history

Key principles:
- Focus on understanding the user's intent
- Plan the analysis approach based on their needs
- Let the pipeline execution happen automatically
- Synthesize results into clear, actionable insights

Natural language handling:
- Parse user requests to understand intent
- Identify key medical concepts of interest
- Determine appropriate focus areas
- Guide the synthesis of results

Remember: The actual agent coordination is handled by the orchestrator's execution engine. Your role is to understand, plan, and synthesize - not to call agents directly."""
    
    def get_tools(self) -> List[Any]:
        """Return the orchestration tools.
        
        Note: Agent calling is handled by the LLM understanding the coordination
        plan and the orchestrator processing the results, not through direct tools.
        """
        return ORCHESTRATOR_TOOLS
    
    def _load_agent_config(self) -> Dict[str, str]:
        """Load agent URLs from configuration."""
        # Try to load from agents.json first
        config_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), 
            "config", 
            "agents.json"
        )
        
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    config = json.load(f)
                    agents = config.get('agents', {})
                    return {
                        name: info['url'] 
                        for name, info in agents.items()
                    }
            except Exception as e:
                logger.warning(f"Failed to load agents.json: {str(e)}")
        
        # Fallback to environment variables
        return {
            'keyword': os.getenv('KEYWORD_AGENT_URL', 'http://keyword-agent:8003'),
            'grep': os.getenv('GREP_AGENT_URL', 'http://grep-agent:8003'),
            'chunk': os.getenv('CHUNK_AGENT_URL', 'http://chunk-agent:8003'),
            'summarize': os.getenv('SUMMARIZE_AGENT_URL', 'http://summarize-agent:8003')
        }
    
    async def _ensure_a2a_client(self):
        """Ensure A2A client is initialized."""
        if self.a2a_client is None:
            self.a2a_client = A2AAgentClient()
            await self.a2a_client.__aenter__()
    
    async def _call_agent(self, agent_name: str, request_data: Dict[str, Any]) -> Dict[str, Any]:
        """Call an agent using A2A standard protocol."""
        agent_url = self.agent_config.get(agent_name)
        if not agent_url:
            raise ValueError(f"No URL configured for agent: {agent_name}")
        
        await self._ensure_a2a_client()
        
        try:
            logger.info(f"Calling {agent_name} agent at {agent_url} using A2A protocol")
            
            result = await self.a2a_client.call_agent(agent_url, request_data)
            
            logger.info(f"✅ A2A call successful for {agent_name}")
            logger.info(f"Response: {str(result)[:200]}...")
            return result
                
        except Exception as e:
            logger.error(f"Error calling {agent_name} agent via A2A: {str(e)}")
            return {"error": str(e)}
    
    async def cleanup(self):
        """Cleanup resources."""
        if self.a2a_client:
            await self.a2a_client.__aexit__(None, None, None)
            self.a2a_client = None
    
    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        """Execute the orchestration pipeline."""
        request_id = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        logger.info(f"🚀 [{request_id}] Starting orchestrator execution")
        
        try:
            # Extract user message using base class method
            message_parts = context.message.parts if context.message else []
            user_message = ""
            
            if message_parts and len(message_parts) > 0:
                first_part = message_parts[0]
                if hasattr(first_part, "root") and isinstance(first_part.root, TextPart):
                    user_message = first_part.root.text
                elif hasattr(first_part, "text"):
                    user_message = first_part.text
            
            if not user_message.strip():
                logger.warning(f"❌ [{request_id}] Empty user message received")
                await event_queue.enqueue_event(
                    new_agent_text_message("Please provide a request to analyze.")
                )
                return
            
            # Parse request data if it's JSON
            request_data = {}
            try:
                request_data = json.loads(user_message)
                document_content = request_data.get("file_content", "")
                file_path = request_data.get("file_path", "document.txt")
            except json.JSONDecodeError:
                # Treat as plain text request
                document_content = user_message
                file_path = "document.txt"
            
            # Ensure we have document content
            if not document_content:
                await event_queue.enqueue_event(
                    new_agent_text_message("Please provide document content to analyze.")
                )
                return
            
            # Create or get task
            task = context.current_task
            if not task:
                default_message = new_agent_text_message("Starting document analysis pipeline...")
                task = new_task(context.message if context.message else default_message)
                if task:
                    await event_queue.enqueue_event(task)
            
            # Create task updater
            updater = TaskUpdater(event_queue, task.id, task.context_id)
            
            # Let the LLM understand and plan first
            await updater.update_status(
                TaskState.working,
                new_agent_text_message("Understanding your request...", task.id, task.id)
            )
            
            # Use base class to get LLM's understanding
            session_id = task.context_id or task.id
            understanding = ""
            plan = ""
            
            async for chunk in self._stream_llm_response(
                f"Analyze this request and create a plan: {user_message[:500]}",
                session_id
            ):
                if chunk.get("is_task_complete", False):
                    understanding = chunk.get("content", "")
                    break
            
            # Now execute the pipeline
            pipeline_results = {}
            
            # Step 1: Keyword Generation
            await updater.update_status(
                TaskState.working,
                new_agent_text_message("Generating search patterns...", task.id, task.id)
            )
            
            keyword_result = await self._call_agent("keyword", {
                "preview": document_content[:1000],
                "focus_areas": request_data.get("focus_areas", []),
                "document_type": request_data.get("document_type", "medical")
            })
            
            if "error" in keyword_result:
                await updater.update_status(
                    TaskState.working,
                    new_agent_text_message(f"Pattern generation had issues: {keyword_result['error']}", task.id, task.id)
                )
            else:
                pipeline_results["patterns"] = keyword_result
                patterns = keyword_result.get("patterns", [])
                
                # Step 2: Grep Search
                await updater.update_status(
                    TaskState.working,
                    new_agent_text_message(f"Searching document with {len(patterns)} patterns...", task.id, task.id)
                )
                
                grep_result = await self._call_agent("grep", {
                    "patterns": patterns,
                    "file_content": document_content,
                    "file_path": file_path
                })
                
                if "error" not in grep_result:
                    pipeline_results["search_results"] = grep_result
                    matches = grep_result.get("matches", [])
                    
                    # Step 3: Chunk Extraction
                    await updater.update_status(
                        TaskState.working,
                        new_agent_text_message(f"Extracting context for {len(matches)} matches...", task.id, task.id)
                    )
                    
                    chunk_result = await self._call_agent("chunk", {
                        "matches": matches,
                        "file_content": document_content,
                        "file_path": file_path
                    })
                    
                    if "error" not in chunk_result:
                        pipeline_results["chunks"] = chunk_result
                        chunks = chunk_result.get("chunks", [])
                        
                        # Step 4: Summarization
                        await updater.update_status(
                            TaskState.working,
                            new_agent_text_message(f"Analyzing {len(chunks)} text chunks...", task.id, task.id)
                        )
                        
                        summarize_result = await self._call_agent("summarize", {
                            "chunks": chunks,
                            "focus_areas": request_data.get("focus_areas", [])
                        })
                        
                        if "error" not in summarize_result:
                            pipeline_results["summaries"] = summarize_result
            
            # Let LLM synthesize the final response
            await updater.update_status(
                TaskState.working,
                new_agent_text_message("Preparing final analysis...", task.id, task.id)
            )
            
            synthesis_prompt = f"""Based on the pipeline results, provide a comprehensive response to the user's request.

User Request: {user_message[:500]}

Pipeline Results:
{json.dumps(pipeline_results, indent=2)[:2000]}

Synthesize these results into a clear, helpful response."""
            
            async for chunk in self._stream_llm_response(synthesis_prompt, session_id):
                if chunk.get("is_task_complete", False):
                    final_response = chunk.get("content", "")
                    
                    # Send final response
                    await updater.update_status(
                        TaskState.working,
                        new_agent_text_message(final_response, task.id, task.id)
                    )
                    
                    # Add as artifact and complete
                    await updater.add_artifact(
                        [Part(root=TextPart(text=final_response))],
                        name="analysis_results"
                    )
                    await updater.complete()
                    break
                else:
                    # Stream intermediate updates
                    update_content = chunk.get("updates", "")
                    if update_content:
                        await updater.update_status(
                            TaskState.working,
                            new_agent_text_message(update_content, task.id, task.id)
                        )
        
        except Exception as e:
            logger.error(f"💥 [{request_id}] Error in orchestrator: {str(e)}", exc_info=True)
            await event_queue.enqueue_event(
                new_agent_text_message(f"An error occurred during orchestration: {str(e)}")
            )




# Load environment at module level
load_dotenv()

# Create enhanced agent card for LLM-powered orchestrator agent
logger.info("🚀 Starting LLM Orchestrator Agent...")
logger.info("📋 Creating enhanced agent card for LLM-powered orchestrator agent...")

agent_card = AgentCard(
    name="Pipeline Orchestrator",
    description="LLM-powered orchestrator that coordinates the medical document analysis pipeline, handling natural language requests and managing agent interactions.",
    version="2.0.0",
    url=os.getenv("HU_APP_URL") or "http://localhost:8003",
    capabilities=AgentCapabilities(
        streaming=True, push_notifications=False, state_transition_history=True
    ),
    skills=[
            AgentSkill(
                id="analyze_medical_document",
                name="Analyze Medical Document",
                description="Orchestrate full pipeline to analyze medical documents based on user requests.",
                tags=["orchestration", "pipeline", "medical", "analysis", "llm"],
                examples=[
                    "Find all diagnosis information in this document",
                    "Summarize the treatment plan",
                    "Extract medication information",
                    "What are the key findings in this report?",
                    "Analyze this oncology consultation note"
                ],
                input_modes=["application/json", "text/plain"],
                output_modes=["application/json", "text/plain"]
            ),
            AgentSkill(
                id="natural_language_processing",
                name="Natural Language Processing",
                description="Understand and process natural language requests for document analysis.",
                tags=["nlp", "understanding", "conversation", "llm"],
                examples=[
                    "What diagnosis does the patient have?",
                    "Show me all medications mentioned",
                    "Find information about cancer staging",
                    "What treatments were recommended?"
                ],
                input_modes=["application/json", "text/plain"],
                output_modes=["application/json", "text/plain"]
            ),
            AgentSkill(
                id="pipeline_coordination",
                name="Pipeline Coordination",
                description="Coordinate multiple agents to process documents efficiently.",
                tags=["coordination", "workflow", "agents", "pipeline"],
                examples=[
                    "Run full analysis pipeline",
                    "Search and summarize findings",
                    "Extract and analyze key sections",
                    "Process document with custom focus"
                ],
                input_modes=["application/json", "text/plain"],
                output_modes=["application/json", "text/plain"]
            ),
            AgentSkill(
                id="error_recovery",
                name="Error Recovery",
                description="Handle pipeline errors gracefully with fallback strategies.",
                tags=["error-handling", "recovery", "resilience"],
                examples=[
                    "Retry with default patterns",
                    "Use partial results",
                    "Fallback to simplified analysis",
                    "Recover from agent failures"
                ],
                input_modes=["application/json", "text/plain"],
                output_modes=["application/json", "text/plain"]
            )
        ],
    default_input_modes=["application/json", "text/plain"],
    default_output_modes=["application/json", "text/plain"],
    provider=AgentProvider(
        organization="ADK Pipeline V2",
        url="https://github.com/Health-Universe/adk-demo-pipeline"
    )
)
logger.info("✅ Agent card created successfully")

# Create the A2A application components
logger.info("🏗️ Building A2A application components...")

logger.info("🤖 Creating LLM Orchestrator Agent Executor...")
agent_executor = LLMOrchestratorAgentExecutor()
logger.info("✅ Agent executor created successfully")
logger.info(f"🔧 Available tools: {[tool.name for tool in agent_executor.get_tools()]}")
logger.info(f"🔗 Connected agents: {list(agent_executor.agent_config.keys())}")

logger.info("📋 Creating task store (In-Memory)...")
task_store = InMemoryTaskStore()
logger.info("✅ Task store initialized")

logger.info("🔄 Creating default request handler...")
request_handler = DefaultRequestHandler(
    agent_executor=agent_executor,
    task_store=task_store,
)
logger.info("✅ Request handler configured")

logger.info("🌐 Building A2A Starlette application...")
logger.info(f"📋 Agent card: {agent_card.name}")
logger.info(f"🎯 Skills available: {len(agent_card.skills)}")

app = A2AStarletteApplication(
    agent_card=agent_card, http_handler=request_handler
).build()

logger.info("✅ A2A Starlette application built successfully")
logger.info("🎯 Application ready for deployment")


if __name__ == "__main__":
    host = "0.0.0.0"
    port = int(os.getenv("AGENT_PORT", "8003"))
    
    logger.info(f"🌐 Starting Orchestrator Agent server on {host}:{port}")
    logger.info(f"📍 Agent URL: {os.getenv('HU_APP_URL', f'http://localhost:{port}')}")
    
    # Run the server with cleanup
    try:
        uvicorn.run(
            app,
            host=host,
            port=port,
            log_level="info"
        )
    finally:
        # Cleanup
        asyncio.run(agent_executor.cleanup())