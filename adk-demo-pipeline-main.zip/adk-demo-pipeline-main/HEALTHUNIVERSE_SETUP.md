# HealthUniverse Deployment Setup

This document contains the configuration for running the A2A pipeline with HealthUniverse-hosted agents.

## Agent URLs

The following agents are deployed on HealthUniverse:

1. **Keyword Agent**: https://www.healthuniverse.com/apps/adk-demo-keyword-agent-f32a8ce0-10d6-44a1-9c5a-fa7d32c1efb3
2. **Grep Agent**: https://www.healthuniverse.com/apps/adk-demo-grep-agent-a7e3dd95-3bfc-41f7-86ec-54cf3498d3b2
3. **Chunk Agent**: https://www.healthuniverse.com/apps/adk-demo-chunk-agent-21683709-c9cf-43ce-aa38-d29cca535570
4. **Summarize Agent**: https://www.healthuniverse.com/apps/adk-demo-summarize-agent-ed16778b-b267-4280-8c6e-c6911d7da65a

## Orchestrator Configuration

To run the orchestrator with these agents:

### 1. Set Environment Variables

```bash
# Point to the HealthUniverse agent registry
export AGENT_REGISTRY_SOURCE=./agents-healthuniverse.json

# Set your orchestrator's public URL (if deployed)
export HU_APP_URL=https://www.healthuniverse.com/apps/your-orchestrator-url

# LLM Configuration (REQUIRED for intelligent orchestrator)
export LLM_PROVIDER=gemini  # or openai, anthropic
export GOOGLE_API_KEY=your-api-key
export LLM_MODEL=gemini-2.0-flash  # optional, defaults to provider's default

# Optional: Configure pipeline limits
export MAX_PATTERNS_TO_SEARCH=20
export MAX_CHUNKS_TO_PROCESS=50
export MAX_CHUNKS_TO_SUMMARIZE=20
```

### 2. Run the Orchestrator

```bash
python -m adk_pipeline.a2a_agents.orchestrator.main
```

## Agent Configuration

For each individual agent deployed on HealthUniverse, ensure these environment variables are set:

### Keyword Agent
```bash
HU_APP_URL=https://www.healthuniverse.com/apps/adk-demo-keyword-agent-f32a8ce0-10d6-44a1-9c5a-fa7d32c1efb3
LLM_PROVIDER=gemini  # or openai, anthropic
GOOGLE_API_KEY=your-api-key
```

### Grep Agent
```bash
HU_APP_URL=https://www.healthuniverse.com/apps/adk-demo-grep-agent-a7e3dd95-3bfc-41f7-86ec-54cf3498d3b2
```

### Chunk Agent
```bash
HU_APP_URL=https://www.healthuniverse.com/apps/adk-demo-chunk-agent-21683709-c9cf-43ce-aa38-d29cca535570
```

### Summarize Agent
```bash
HU_APP_URL=https://www.healthuniverse.com/apps/adk-demo-summarize-agent-ed16778b-b267-4280-8c6e-c6911d7da65a
LLM_PROVIDER=gemini  # or openai, anthropic
GOOGLE_API_KEY=your-api-key
```

## Testing the Setup

Once the orchestrator is running, you can interact with it in two ways:

### Natural Language Conversation

```bash
curl -X POST http://localhost:9000/invoke \
  -H "Content-Type: application/json" \
  -d '"Find all cancer-related information in this document: PATIENT: John Doe..."'
```

### Structured Document Request

```bash
curl -X POST http://localhost:9000/invoke \
  -H "Content-Type: application/json" \
  -d '{
    "text": "PATIENT: John Doe\nDATE: 2024-01-15\n\nCHIEF COMPLAINT:\nPersistent cough for 2 weeks\n\nDIAGNOSIS:\nAcute bronchitis\n\nHISTORY:\nPrevious lung cancer in remission",
    "options": {
      "request": "What diagnoses are mentioned?",
      "doc_type": "medical",
      "max_results": 10
    }
  }'
```

The intelligent orchestrator will:
1. Understand your request using LLM
2. Guide the keyword agent to generate appropriate patterns
3. Search with grep agent using all relevant terms
4. Extract meaningful chunks
5. Summarize with focus on your specific question
6. Provide a natural language response

## File Handling Note

The current implementation passes document content directly. For production with large documents, consider implementing one of these approaches:

1. **Shared Storage**: Upload documents to S3/GCS and pass URLs
2. **Document Service**: Create a separate service for document storage
3. **Modified Agents**: Update grep/chunk agents to accept content directly

See `orchestrator/workflow.py` for detailed file handling strategies.