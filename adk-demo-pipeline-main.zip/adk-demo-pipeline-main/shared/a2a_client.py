"""
A2A Client utilities for agent-to-agent communication.
Uses the standard A2A SDK client instead of raw HTTP calls.
"""

import logging
import json
from typing import Dict, Any, Optional, AsyncIterator, Tuple
import httpx

from a2a.client import (
    ClientFactory,
    ClientConfig,
    A2ACardResolver,
    create_text_message_object
)
from a2a.types import (
    Role,
    Task,
    TaskStatusUpdateEvent,
    TaskArtifactUpdateEvent,
    Message,
    Part,
    TextPart
)
from a2a.utils.constants import (
    AGENT_CARD_WELL_KNOWN_PATH,
    PREV_AGENT_CARD_WELL_KNOWN_PATH
)

logger = logging.getLogger(__name__)


class A2AAgentClient:
    """Client for calling other A2A agents using the standard protocol."""
    
    def __init__(self, http_client: Optional[httpx.AsyncClient] = None):
        """Initialize the A2A agent client.
        
        Args:
            http_client: Optional HTTP client to reuse. If None, creates a new one.
        """
        self._http_client = http_client
        self._owns_http_client = http_client is None
        self._client_cache: Dict[str, Any] = {}
        
    async def __aenter__(self):
        """Async context manager entry."""
        if self._owns_http_client:
            self._http_client = httpx.AsyncClient(timeout=30.0)
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        if self._owns_http_client and self._http_client:
            await self._http_client.aclose()
            
    async def _ensure_http_client(self):
        """Ensure HTTP client is available."""
        if not self._http_client:
            self._http_client = httpx.AsyncClient(timeout=30.0)
            self._owns_http_client = True
            
    async def _get_or_create_client(self, agent_url: str):
        """Get cached client or create new one for an agent.
        
        Args:
            agent_url: Base URL of the agent
            
        Returns:
            A2A Client instance
        """
        if agent_url in self._client_cache:
            return self._client_cache[agent_url]
            
        await self._ensure_http_client()
        
        # Fetch agent card - try new path first, then old path
        logger.info(f"Fetching agent card from {agent_url}")
        
        # Try new path first
        card_resolver = A2ACardResolver(
            self._http_client,
            base_url=agent_url
        )
        
        agent_card = None
        try:
            logger.debug(f"Trying new agent card path: {AGENT_CARD_WELL_KNOWN_PATH}")
            agent_card = await card_resolver.get_agent_card()
            logger.info(f"Successfully fetched agent card from new path: {agent_card.name} v{agent_card.version}")
        except Exception as e:
            # Check if it's a 404 or if we should try the old path anyway
            should_try_old_path = False
            
            # Handle httpx.HTTPStatusError
            if hasattr(e, 'response'):
                # httpx exception with response
                status_code = getattr(e.response, 'status_code', None)
                if status_code == 404:
                    should_try_old_path = True
                    logger.info(f"Agent card not found at new path (404)")
                elif status_code == 403:
                    # For 403, also try old path as the new path might not be accessible
                    should_try_old_path = True
                    logger.info(f"Access forbidden at new path (403), will try old path")
                else:
                    logger.info(f"HTTP error {status_code} fetching from new path")
            elif hasattr(e, 'status_code'):
                # Direct status code attribute
                if e.status_code == 404:
                    should_try_old_path = True
                    logger.info(f"Agent card not found at new path (404)")
                elif e.status_code == 403:
                    # For 403, also try old path as the new path might not be accessible
                    should_try_old_path = True
                    logger.info(f"Access forbidden at new path (403), will try old path")
                else:
                    logger.info(f"HTTP error {e.status_code} fetching from new path")
            else:
                # For other exceptions, try old path as fallback
                should_try_old_path = True
                logger.info(f"Error fetching from new path: {type(e).__name__}: {str(e)[:100]}")
                
            if should_try_old_path:
                logger.info(f"Trying old agent card path: {PREV_AGENT_CARD_WELL_KNOWN_PATH}")
                # Try old path
                try:
                    # Create resolver with old path
                    card_resolver = A2ACardResolver(
                        self._http_client,
                        base_url=agent_url,
                        agent_card_path=PREV_AGENT_CARD_WELL_KNOWN_PATH
                    )
                    agent_card = await card_resolver.get_agent_card()
                    logger.info(f"Successfully fetched agent card from old path: {agent_card.name} v{agent_card.version}")
                except Exception as old_e:
                    logger.error(f"Failed to fetch agent card from both paths")
                    logger.error(f"New path error: {type(e).__name__}: {str(e)[:200]}")
                    logger.error(f"Old path error: {type(old_e).__name__}: {str(old_e)[:200]}")
                    # Re-raise the original error if it was more specific
                    if hasattr(e, 'response') or hasattr(e, 'status_code'):
                        raise e
                    else:
                        raise old_e
            else:
                # Don't try old path, just raise the error
                logger.error(f"Failed to fetch agent card from new path, not trying old path")
                raise
            
        if not agent_card:
            raise Exception(f"Could not fetch agent card from {agent_url}")
        
        # Create client
        client_config = ClientConfig(
            streaming=agent_card.capabilities.streaming if agent_card.capabilities else False,
            httpx_client=self._http_client,
            supported_transports=[]  # JSON-RPC only for now
        )
        
        factory = ClientFactory(client_config)
        client = factory.create(agent_card)
        
        self._client_cache[agent_url] = client
        return client
        
    async def call_agent(
        self, 
        agent_url: str, 
        request_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Call an agent and get the response.
        
        This method handles the full request/response cycle, waiting for
        the task to complete and returning the final result.
        
        Args:
            agent_url: Base URL of the agent
            request_data: Data to send to the agent
            
        Returns:
            Response data from the agent
        """
        logger.info(f"Calling agent at {agent_url}")
        
        # Get or create client
        client = await self._get_or_create_client(agent_url)
        
        # Create message
        message_content = json.dumps(request_data)
        message = create_text_message_object(
            role=Role.user,
            content=message_content
        )
        
        logger.info(f"Sending message with content: {message_content[:200]}...")
        
        # Send message and collect response
        task = None
        final_response = None
        artifacts = []
        
        try:
            async for event in client.send_message(message):
                if isinstance(event, tuple):
                    # Task update event
                    task, update = event
                    logger.info(f"Task {task.id} - State: {task.state}")
                    
                    if isinstance(update, TaskStatusUpdateEvent):
                        if update.message:
                            # Extract text from message parts
                            for part in update.message.parts:
                                if hasattr(part, 'root') and isinstance(part.root, TextPart):
                                    logger.info(f"Status update: {part.root.text[:100]}...")
                                    
                    elif isinstance(update, TaskArtifactUpdateEvent):
                        logger.info(f"Received artifact: {update.name}")
                        artifacts.append(update)
                        
                    # Check if task is complete
                    if task.state in ['completed', 'failed', 'cancelled']:
                        logger.info(f"Task completed with state: {task.state}")
                        break
                else:
                    # Direct message response (shouldn't happen with send_message)
                    logger.info(f"Received direct message: {event}")
                    
        except Exception as e:
            logger.error(f"Error calling agent: {str(e)}")
            return {"error": str(e)}
            
        # Extract final response from artifacts or task
        if artifacts:
            # Get the last artifact's content
            last_artifact = artifacts[-1]
            if last_artifact.artifact and last_artifact.artifact.parts:
                response_parts = []
                for part in last_artifact.artifact.parts:
                    if hasattr(part, 'root') and isinstance(part.root, TextPart):
                        response_parts.append(part.root.text)
                final_response = "\n".join(response_parts)
        
        if final_response:
            try:
                # Try to parse as JSON
                return json.loads(final_response)
            except json.JSONDecodeError:
                # Return as text if not JSON
                return {"response": final_response}
        else:
            return {"error": "No response received from agent"}
            
    async def stream_agent_response(
        self,
        agent_url: str,
        request_data: Dict[str, Any]
    ) -> AsyncIterator[Tuple[str, Any]]:
        """Stream responses from an agent.
        
        Yields tuples of (event_type, data) where event_type can be:
        - "task_created": Task was created
        - "status_update": Status update with message
        - "artifact": Artifact received
        - "completed": Task completed
        - "error": Error occurred
        
        Args:
            agent_url: Base URL of the agent
            request_data: Data to send to the agent
            
        Yields:
            Tuples of (event_type, data)
        """
        logger.info(f"Starting streaming call to agent at {agent_url}")
        
        # Get or create client
        client = await self._get_or_create_client(agent_url)
        
        # Create message
        message_content = json.dumps(request_data)
        message = create_text_message_object(
            role=Role.user,
            content=message_content
        )
        
        try:
            async for event in client.send_message(message):
                if isinstance(event, tuple):
                    task, update = event
                    
                    if isinstance(update, TaskStatusUpdateEvent):
                        if update.message:
                            # Extract text from message parts
                            text_parts = []
                            for part in update.message.parts:
                                if hasattr(part, 'root') and isinstance(part.root, TextPart):
                                    text_parts.append(part.root.text)
                            if text_parts:
                                yield ("status_update", "\n".join(text_parts))
                                
                    elif isinstance(update, TaskArtifactUpdateEvent):
                        # Extract artifact content
                        if update.artifact and update.artifact.parts:
                            artifact_texts = []
                            for part in update.artifact.parts:
                                if hasattr(part, 'root') and isinstance(part.root, TextPart):
                                    artifact_texts.append(part.root.text)
                            if artifact_texts:
                                yield ("artifact", {
                                    "name": update.name,
                                    "content": "\n".join(artifact_texts)
                                })
                    
                    # Check if task is complete
                    if task.state == 'completed':
                        yield ("completed", {"task_id": task.id})
                        break
                    elif task.state in ['failed', 'cancelled']:
                        yield ("error", {
                            "task_id": task.id,
                            "state": task.state,
                            "error": "Task failed or was cancelled"
                        })
                        break
                        
        except Exception as e:
            logger.error(f"Error in streaming call: {str(e)}")
            yield ("error", {"error": str(e)})