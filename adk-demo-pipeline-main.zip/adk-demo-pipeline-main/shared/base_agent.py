"""
Base class for LLM-powered A2A agents following nutrition_example.py pattern.
"""
import os
import json
import logging
import asyncio
import time
from datetime import datetime
from dotenv import load_dotenv
from typing import Dict, Any, Optional, AsyncIterable, List
from abc import ABC, abstractmethod

# Google ADK and Gemini imports
from google.adk.agents.llm_agent import LlmAgent
from google.adk.runners import Runner
from google.adk.artifacts import InMemoryArtifactService
from google.adk.sessions import InMemorySessionService
from google.adk.memory import InMemoryMemoryService
from google.adk.tools import FunctionTool
from google.adk.models.lite_llm import LiteLlm

# A2A imports
from a2a.utils import new_task
from a2a.types import Task, TaskState
from a2a.server.tasks import InMemoryTaskStore, TaskUpdater
from a2a.server.apps import A2AStarletteApplication
from a2a.types import (
    AgentCard,
    AgentProvider,
    AgentSkill,
    AgentCapabilities,
    Part,
    TextPart,
)
from a2a.utils import new_agent_text_message
from a2a.utils.errors import ServerError, UnsupportedOperationError
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


class BaseLLMAgentExecutor(AgentExecutor, ABC):
    """Base class for LLM-powered A2A agents following nutrition_example.py pattern."""
    
    def __init__(self):
        super().__init__()
        logger.info(f"🚀 Initializing {self.__class__.__name__}")
        logger.info("📊 Loading environment configuration...")
        
        load_dotenv()
        
        # Check API key configuration
        google_api_key = os.getenv("GOOGLE_API_KEY")
        openai_api_key = os.getenv("OPENAI_API_KEY")
        anthropic_api_key = os.getenv("ANTHROPIC_API_KEY")
        
        logger.info(
            f"🔑 Google API Key: {'✅ Configured' if google_api_key else '❌ Missing'}"
        )
        logger.info(
            f"🔑 OpenAI API Key: {'✅ Configured' if openai_api_key else '❌ Missing'}"
        )
        logger.info(
            f"🔑 Anthropic API Key: {'✅ Configured' if anthropic_api_key else '❌ Missing'}"
        )
        
        # Auto-detect which LLM provider to use based on available API keys
        # Priority: Google > OpenAI > Anthropic
        if google_api_key:
            # Use Gemini if Google API key is available
            self._model = os.getenv("GEMINI_MODEL", "gemini-2.0-flash-001")
            logger.info(f"🎯 Using Google Gemini provider")
        elif openai_api_key:
            # Use OpenAI if only OpenAI API key is available
            # ADK supports OpenAI through LiteLLM
            self._model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
            logger.info(f"🎯 Using OpenAI provider via LiteLLM")
            # Ensure LiteLLM uses the OpenAI API key
            os.environ["OPENAI_API_KEY"] = openai_api_key
        elif anthropic_api_key:
            # Use Anthropic if only Anthropic API key is available
            # ADK supports Anthropic through LiteLLM
            self._model = os.getenv("ANTHROPIC_MODEL", "claude-3-5-haiku-20241022")
            logger.info(f"🎯 Using Anthropic provider via LiteLLM")
            # Ensure LiteLLM uses the Anthropic API key
            os.environ["ANTHROPIC_API_KEY"] = anthropic_api_key
        else:
            raise ValueError(
                "❌ No LLM API key found! Please set either GOOGLE_API_KEY, OPENAI_API_KEY, or ANTHROPIC_API_KEY"
            )
        
        self._user_id = f"{self.get_agent_name()}_user"
        
        logger.info(f"🤖 Configuring LLM agent with model: {self._model}")
        logger.info(f"👤 Agent user ID: {self._user_id}")
        
        # Build the LLM agent
        logger.info("🔧 Building LLM agent...")
        self._agent = self._build_llm_agent()
        logger.info(f"✅ LLM agent '{self._agent.name}' created successfully")
        
        # Create runner with services for session management
        logger.info("🏃 Creating runner with session management services...")
        self._runner = Runner(
            app_name=self._agent.name,
            agent=self._agent,
            artifact_service=InMemoryArtifactService(),
            session_service=InMemorySessionService(),
            memory_service=InMemoryMemoryService(),
        )
        logger.info("📝 Session management services initialized")
        logger.info("🎯 Memory management services initialized")
        logger.info("📦 Artifact management services initialized")
        
        logger.info(f"✅ {self.__class__.__name__} initialization complete!")
        logger.info(
            f"🎯 Agent ready with {len(self._agent.tools)} tools available"
        )
        
        # Heartbeat configuration for long-running tasks
        self._heartbeat_interval = float(os.getenv("AGENT_HEARTBEAT_INTERVAL", "10.0"))
        self._chunk_timeout = float(os.getenv("AGENT_CHUNK_TIMEOUT", "120.0"))
        logger.info(f"💓 Heartbeat interval: {self._heartbeat_interval}s")
        logger.info(f"⏱️ Chunk timeout: {self._chunk_timeout}s")
    
    @abstractmethod
    def get_agent_name(self) -> str:
        """Return the agent's name."""
        pass
    
    @abstractmethod
    def get_system_instruction(self) -> str:
        """Return the system instruction for the LLM agent."""
        pass
    
    @abstractmethod
    def get_tools(self) -> List[FunctionTool]:
        """Return the list of tools for this agent."""
        pass
    
    def _build_llm_agent(self) -> LlmAgent:
        """Build the LLM agent with tools and instructions."""
        logger.info("📝 Creating agent-specific system instructions...")
        
        instruction = self.get_system_instruction()
        tools = self.get_tools()
        
        logger.info(f"🛠️ Registering {len(tools)} tools...")
        logger.info(f"📋 Tools: {[tool.name for tool in tools]}")
        
        logger.info("🔨 Creating LlmAgent instance...")
        
        # Check if we need to use LiteLLM for non-Gemini models
        if self._model.startswith("gpt-") or self._model.startswith("claude-"):
            provider = "OpenAI" if self._model.startswith("gpt-") else "Anthropic"
            logger.info(f"🔄 Using LiteLLM for {provider} model: {self._model}")
            # Create LiteLLM instance for OpenAI/Anthropic
            model = LiteLlm(model=self._model)
        else:
            # Use the model string directly (for Gemini)
            model = self._model
        
        agent = LlmAgent(
            model=model,
            name=self.get_agent_name().lower().replace(" ", "_"),
            description=f"LLM-powered {self.get_agent_name()}",
            instruction=instruction,
            tools=tools,
        )
        logger.info(f"✅ LlmAgent created: {agent.name}")
        
        return agent
    
    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        """Execute method with LLM streaming support."""
        request_id = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        logger.info(f"🚀 [{request_id}] Starting LLM request execution")
        
        try:
            # Extract the user's message
            logger.info(f"📝 [{request_id}] Extracting user message from context...")
            message_parts = context.message.parts if context.message else []
            user_message = ""
            
            if message_parts and len(message_parts) > 0:
                first_part = message_parts[0]
                logger.info(
                    f"🔍 [{request_id}] First part type: {type(first_part).__name__}"
                )
                
                # Handle different part types
                if hasattr(first_part, "root") and isinstance(
                    first_part.root, TextPart
                ):
                    user_message = first_part.root.text
                elif hasattr(first_part, "text"):
                    user_message = first_part.text
                else:
                    logger.warning(
                        f"⚠️ [{request_id}] First message part is not a TextPart"
                    )
            
            if not user_message.strip():
                logger.warning(f"❌ [{request_id}] Empty user message received")
                response_msg = f"Please provide input for the {self.get_agent_name()}"
                await event_queue.enqueue_event(new_agent_text_message(response_msg))
                return
            
            # Handle task context
            logger.info(f"🔍 [{request_id}] Checking task context...")
            task = context.current_task
            session_id = None
            
            if not task:
                logger.info(
                    f"✨ [{request_id}] No existing task found - creating new task"
                )
                default_message = new_agent_text_message(
                    f"Processing with {self.get_agent_name()}..."
                )
                task = new_task(context.message if context.message else default_message)
                if task:
                    logger.info(
                        f"📋 [{request_id}] New task created with ID: {task.id}"
                    )
                    await event_queue.enqueue_event(task)
                    session_id = task.id
            else:
                session_id = task.context_id or task.id
                logger.info(f"♻️ [{request_id}] Continuing existing task ID: {task.id}")
            
            # Create task updater
            logger.info(f"📡 [{request_id}] Creating task updater for streaming...")
            updater = TaskUpdater(event_queue, task.id, task.context_id)
            
            # Stream responses from the LLM agent
            logger.info(
                f"🌊 [{request_id}] Starting LLM streaming for session: {session_id}"
            )
            
            has_updates = False
            chunk_count = 0
            last_heartbeat_time = time.time()
            
            # Add timeout to prevent hanging tasks
            try:
                # Create an async generator with timeout
                stream_generator = self._stream_llm_response(user_message, session_id)
                
                # Process chunks with timeout
                while True:
                    try:
                        # Check if we need to send a heartbeat
                        current_time = time.time()
                        if current_time - last_heartbeat_time > self._heartbeat_interval:
                            logger.info(f"💓 [{request_id}] Sending heartbeat update")
                            await updater.update_status(
                                TaskState.working,
                                new_agent_text_message(
                                    "Still processing your request...", 
                                    session_id, 
                                    task.id
                                ),
                            )
                            last_heartbeat_time = current_time
                        
                        response_chunk = await asyncio.wait_for(
                            stream_generator.__anext__(), 
                            timeout=self._chunk_timeout
                        )
                        chunk_count += 1
                        logger.info(
                            f"📦 [{request_id}] Processing chunk #{chunk_count}"
                        )
                        
                        if response_chunk.get("is_task_complete", False):
                            # Final response
                            final_content = response_chunk.get("content", "")
                            has_updates = True
                            logger.info(
                                f"✅ [{request_id}] Task completed with final response"
                            )
                            
                            # Send final response
                            if final_content.strip():
                                await updater.update_status(
                                    TaskState.working,
                                    new_agent_text_message(
                                        final_content, session_id, task.id
                                    ),
                                )
                            
                            # Add as artifact and complete
                            await updater.add_artifact(
                                [Part(root=TextPart(text=final_content))],
                                name="agent_response",
                            )
                            await updater.complete()
                            break
                        else:
                            # Intermediate update
                            update_content = response_chunk.get("updates", "")
                            if update_content:
                                has_updates = True
                                await updater.update_status(
                                    TaskState.working,
                                    new_agent_text_message(
                                        update_content, session_id, task.id
                                    ),
                                )
                    except StopAsyncIteration:
                        # Normal end of async generator
                        break
                                
            except asyncio.TimeoutError:
                logger.error(f"⏰ [{request_id}] Streaming timeout after {self._chunk_timeout} seconds")
                await event_queue.enqueue_event(
                    new_agent_text_message(
                        f"The request took too long to process (timeout: {self._chunk_timeout}s). Please try again with a simpler request or contact support."
                    )
                )
                return
            
            if not has_updates:
                logger.error(
                    f"❌ [{request_id}] No updates received from LLM agent"
                )
                error_msg = (
                    "I couldn't process your request. Please try again."
                )
                await updater.add_artifact(
                    [Part(root=TextPart(text=error_msg))],
                    name="error_response",
                )
                await updater.complete()
                
        except asyncio.CancelledError:
            logger.warning(f"🛑 [{request_id}] Task execution was cancelled")
            raise
        except Exception as e:
            logger.error(
                f"💥 [{request_id}] Critical error during LLM execution: {str(e)}",
                exc_info=True,
            )
            error_message = (
                f"An error occurred: {str(e)}"
            )
            await event_queue.enqueue_event(new_agent_text_message(error_message))
    
    async def cancel(self, request: RequestContext, event_queue: EventQueue) -> None:
        """Cancel the current request."""
        logger.info(f"🛑 Cancellation request received for {self.get_agent_name()}")
        logger.warning(
            "⚠️ Cancel operation not supported - raising UnsupportedOperationError"
        )
        raise ServerError(error=UnsupportedOperationError())
    
    async def _stream_llm_response(
        self, query: str, session_id: Optional[str] = None
    ) -> AsyncIterable[Dict[str, Any]]:
        """Stream responses from the LLM agent."""
        logger.info(f"🧠 Processing query: {query[:100]}...")
        logger.info(f"🆔 Target session ID: {session_id}")
        
        session = None
        try:
            # Get or create session
            logger.info(
                f"🔍 Attempting to retrieve session for app: {self._agent.name}"
            )
            session = await self._runner.session_service.get_session(
                app_name=self._agent.name,
                user_id=self._user_id,
                session_id=session_id,
            )
            
            if session is None:
                logger.info(f"✨ Creating new session for user {self._user_id}")
                session = await self._runner.session_service.create_session(
                    app_name=self._agent.name,
                    user_id=self._user_id,
                    state={},
                    session_id=session_id,
                )
                logger.info(f"✅ Created new session: {session.id}")
            else:
                logger.info(f"♻️ Using existing session: {session.id}")
            
            # Stream the LLM response
            logger.info(f"🚀 Starting LLM runner for session {session.id}")
            
            # Format the message for Google ADK
            from google.genai import types
            formatted_message = types.Content(
                role="user", parts=[types.Part(text=query)]
            )
            
            event_count = 0
            async for event in self._runner.run_async(
                user_id=self._user_id,
                session_id=session.id,
                new_message=formatted_message,
            ):
                event_count += 1
                logger.info(f"📨 Received event #{event_count} from LLM runner")
                
                if event.is_final_response():
                    # Final response
                    logger.info(f"🏁 Processing final response event")
                    if event.content and event.content.parts:
                        full_response = ""
                        for part in event.content.parts:
                            if hasattr(part, "text") and part.text is not None:
                                full_response += part.text
                        
                        logger.info(
                            f"✅ Completed response generation for session {session.id}"
                        )
                        
                        yield {
                            "is_task_complete": True,
                            "content": full_response,
                            "session_id": session.id,
                        }
                    else:
                        logger.warning(f"⚠️ Final event has no content")
                        yield {
                            "is_task_complete": True,
                            "content": "Processing complete.",
                            "session_id": session.id,
                        }
                else:
                    # Intermediate streaming update
                    if hasattr(event, "content") and event.content:
                        partial_content = ""
                        if hasattr(event.content, "parts") and event.content.parts:
                            for part in event.content.parts:
                                if hasattr(part, "text") and part.text is not None:
                                    partial_content += part.text
                        
                        if partial_content:
                            yield {
                                "is_task_complete": False,
                                "updates": partial_content,
                                "session_id": session.id,
                            }
                    else:
                        # Generic processing update
                        yield {
                            "is_task_complete": False,
                            "updates": "Processing...",
                            "session_id": session.id,
                        }
            
            logger.info(
                f"📈 LLM streaming completed - processed {event_count} events"
            )
            
        except asyncio.CancelledError:
            logger.warning(f"🛑 LLM streaming was cancelled for session: {session_id}")
            raise
        except Exception as e:
            logger.error(
                f"💥 Critical error during LLM streaming: {str(e)}", exc_info=True
            )
            
            error_response = f"I encountered an error: {str(e)}"
            yield {
                "is_task_complete": True,
                "content": error_response,
                "session_id": session_id,
            }