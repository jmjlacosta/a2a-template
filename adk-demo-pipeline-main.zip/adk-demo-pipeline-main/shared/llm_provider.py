"""
LLM Provider Abstraction Layer
Provides a unified interface for different LLM providers (Gemini, OpenAI, Anthropic)
to ensure the A2A agents are provider-agnostic.
"""
from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional, Union
from enum import Enum
from dataclasses import dataclass
import json
import os
import structlog

logger = structlog.get_logger()


class LLMProvider(str, Enum):
    """Supported LLM providers"""
    GEMINI = "gemini"
    OPENAI = "openai"
    ANTHROPIC = "anthropic"


@dataclass
class LLMResponse:
    """Standard response from LLM providers"""
    content: str
    usage: Optional[Dict[str, int]] = None
    model: Optional[str] = None
    finish_reason: Optional[str] = None


@dataclass
class StructuredOutput:
    """Structured output with validation"""
    data: Dict[str, Any]
    valid: bool
    errors: Optional[List[str]] = None


class LLMInterface(ABC):
    """
    Abstract interface for LLM providers.
    All providers must implement these methods to ensure compatibility.
    """
    
    def __init__(self, api_key: str, model: str, **kwargs):
        self.api_key = api_key
        self.model = model
        self.config = kwargs
        
    @abstractmethod
    async def generate(
        self, 
        prompt: str, 
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> LLMResponse:
        """
        Generate text from a prompt.
        
        Args:
            prompt: The input prompt
            temperature: Sampling temperature (0-1)
            max_tokens: Maximum tokens to generate
            **kwargs: Provider-specific parameters
            
        Returns:
            LLMResponse with generated content
        """
        pass
    
    @abstractmethod
    async def generate_structured(
        self, 
        prompt: str, 
        schema: Dict[str, Any],
        temperature: float = 0.3,
        **kwargs
    ) -> StructuredOutput:
        """
        Generate structured output following a JSON schema.
        
        Args:
            prompt: The input prompt
            schema: JSON schema for the output
            temperature: Lower temperature for structured output
            **kwargs: Provider-specific parameters
            
        Returns:
            StructuredOutput with validated data
        """
        pass
    
    def _validate_against_schema(self, data: Any, schema: Dict[str, Any]) -> StructuredOutput:
        """Validate data against a JSON schema"""
        try:
            from jsonschema import validate, ValidationError
            validate(instance=data, schema=schema)
            return StructuredOutput(data=data, valid=True)
        except ValidationError as e:
            return StructuredOutput(
                data=data if isinstance(data, dict) else {},
                valid=False,
                errors=[str(e)]
            )
        except Exception as e:
            return StructuredOutput(
                data={},
                valid=False,
                errors=[f"Validation error: {str(e)}"]
            )


class GeminiProvider(LLMInterface):
    """Google Gemini provider implementation"""
    
    def __init__(self, api_key: str, model: str = "gemini-2.0-flash", **kwargs):
        super().__init__(api_key, model, **kwargs)
        try:
            import google.generativeai as genai
            genai.configure(api_key=api_key)
            self.client = genai.GenerativeModel(model)
            self._genai = genai
        except ImportError:
            raise ImportError("google-generativeai package not installed. Run: pip install google-generativeai")
    
    async def generate(
        self, 
        prompt: str, 
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> LLMResponse:
        """Generate text using Gemini"""
        try:
            generation_config = {
                "temperature": temperature,
                "max_output_tokens": max_tokens or 2048,
                **kwargs
            }
            
            response = await self.client.generate_content_async(
                prompt,
                generation_config=generation_config
            )
            
            return LLMResponse(
                content=response.text,
                model=self.model,
                finish_reason="stop"
            )
        except Exception as e:
            logger.error(f"Gemini generation error: {e}")
            raise
    
    async def generate_structured(
        self, 
        prompt: str, 
        schema: Dict[str, Any],
        temperature: float = 0.3,
        **kwargs
    ) -> StructuredOutput:
        """Generate structured output with Gemini"""
        # Add schema instruction to prompt
        structured_prompt = f"""{prompt}

Respond with valid JSON that matches this schema:
```json
{json.dumps(schema, indent=2)}
```

Ensure your response is ONLY valid JSON, no markdown or explanations."""
        
        try:
            response = await self.generate(
                structured_prompt, 
                temperature=temperature,
                **kwargs
            )
            
            # Parse JSON from response
            content = response.content.strip()
            # Remove markdown code blocks if present
            if content.startswith("```json"):
                content = content[7:]
            if content.endswith("```"):
                content = content[:-3]
            content = content.strip()
            
            data = json.loads(content)
            return self._validate_against_schema(data, schema)
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON parsing error: {e}")
            return StructuredOutput(
                data={},
                valid=False,
                errors=[f"JSON parsing error: {str(e)}"]
            )
        except Exception as e:
            logger.error(f"Gemini structured generation error: {e}")
            return StructuredOutput(
                data={},
                valid=False,
                errors=[f"Generation error: {str(e)}"]
            )


class OpenAIProvider(LLMInterface):
    """OpenAI provider implementation"""
    
    def __init__(self, api_key: str, model: str = "gpt-4-turbo-preview", **kwargs):
        super().__init__(api_key, model, **kwargs)
        try:
            from openai import AsyncOpenAI
            self.client = AsyncOpenAI(api_key=api_key)
        except ImportError:
            raise ImportError("openai package not installed. Run: pip install openai")
    
    async def generate(
        self, 
        prompt: str, 
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> LLMResponse:
        """Generate text using OpenAI"""
        try:
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=temperature,
                max_tokens=max_tokens,
                **kwargs
            )
            
            message = response.choices[0].message
            return LLMResponse(
                content=message.content,
                usage=response.usage.model_dump() if response.usage else None,
                model=response.model,
                finish_reason=response.choices[0].finish_reason
            )
        except Exception as e:
            logger.error(f"OpenAI generation error: {e}")
            raise
    
    async def generate_structured(
        self, 
        prompt: str, 
        schema: Dict[str, Any],
        temperature: float = 0.3,
        **kwargs
    ) -> StructuredOutput:
        """Generate structured output with OpenAI"""
        # Use JSON mode if available (GPT-4 Turbo)
        if "gpt-4" in self.model and "response_format" not in kwargs:
            kwargs["response_format"] = {"type": "json_object"}
        
        structured_prompt = f"""{prompt}

Respond with valid JSON that matches this schema:
{json.dumps(schema, indent=2)}"""
        
        try:
            response = await self.generate(
                structured_prompt,
                temperature=temperature,
                **kwargs
            )
            
            data = json.loads(response.content)
            return self._validate_against_schema(data, schema)
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON parsing error: {e}")
            return StructuredOutput(
                data={},
                valid=False,
                errors=[f"JSON parsing error: {str(e)}"]
            )
        except Exception as e:
            logger.error(f"OpenAI structured generation error: {e}")
            return StructuredOutput(
                data={},
                valid=False,
                errors=[f"Generation error: {str(e)}"]
            )


class AnthropicProvider(LLMInterface):
    """Anthropic Claude provider implementation"""
    
    def __init__(self, api_key: str, model: str = "claude-3-opus-20240229", **kwargs):
        super().__init__(api_key, model, **kwargs)
        try:
            from anthropic import AsyncAnthropic
            self.client = AsyncAnthropic(api_key=api_key)
        except ImportError:
            raise ImportError("anthropic package not installed. Run: pip install anthropic")
    
    async def generate(
        self, 
        prompt: str, 
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> LLMResponse:
        """Generate text using Claude"""
        try:
            response = await self.client.messages.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=temperature,
                max_tokens=max_tokens or 2048,
                **kwargs
            )
            
            # Extract text from content blocks
            content = ""
            for block in response.content:
                if block.type == "text":
                    content += block.text
            
            return LLMResponse(
                content=content,
                usage={
                    "prompt_tokens": response.usage.input_tokens,
                    "completion_tokens": response.usage.output_tokens
                } if response.usage else None,
                model=response.model,
                finish_reason=response.stop_reason
            )
        except Exception as e:
            logger.error(f"Anthropic generation error: {e}")
            raise
    
    async def generate_structured(
        self, 
        prompt: str, 
        schema: Dict[str, Any],
        temperature: float = 0.3,
        **kwargs
    ) -> StructuredOutput:
        """Generate structured output with Claude"""
        structured_prompt = f"""{prompt}

Respond with valid JSON that matches this schema:
```json
{json.dumps(schema, indent=2)}
```

Important: Respond ONLY with valid JSON, no additional text or markdown."""
        
        try:
            response = await self.generate(
                structured_prompt,
                temperature=temperature,
                **kwargs
            )
            
            content = response.content.strip()
            # Remove markdown if present
            if content.startswith("```"):
                content = content.split("\n", 1)[1]
            if content.endswith("```"):
                content = content.rsplit("\n", 1)[0]
            
            data = json.loads(content)
            return self._validate_against_schema(data, schema)
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON parsing error: {e}")
            return StructuredOutput(
                data={},
                valid=False,
                errors=[f"JSON parsing error: {str(e)}"]
            )
        except Exception as e:
            logger.error(f"Anthropic structured generation error: {e}")
            return StructuredOutput(
                data={},
                valid=False,
                errors=[f"Generation error: {str(e)}"]
            )


def create_llm_provider(
    provider: Union[str, LLMProvider],
    api_key: Optional[str] = None,
    model: Optional[str] = None,
    **kwargs
) -> LLMInterface:
    """
    Factory function to create LLM provider instances.
    
    Args:
        provider: Provider name or enum
        api_key: API key (can also be set via environment)
        model: Model name (uses defaults if not specified)
        **kwargs: Additional provider-specific configuration
        
    Returns:
        LLMInterface implementation for the specified provider
        
    Raises:
        ValueError: If provider is not supported
        ImportError: If provider package is not installed
    """
    # Convert string to enum if needed
    if isinstance(provider, str):
        try:
            provider = LLMProvider(provider.lower())
        except ValueError:
            raise ValueError(f"Unsupported provider: {provider}")
    
    # Get API key from environment if not provided
    if not api_key:
        env_key_map = {
            LLMProvider.GEMINI: "GOOGLE_API_KEY",
            LLMProvider.OPENAI: "OPENAI_API_KEY",
            LLMProvider.ANTHROPIC: "ANTHROPIC_API_KEY"
        }
        env_var = env_key_map.get(provider)
        if env_var:
            api_key = os.getenv(env_var) or os.getenv("LLM_API_KEY")
        
        if not api_key:
            raise ValueError(f"API key not provided for {provider.value}")
    
    # Provider class mapping
    provider_classes = {
        LLMProvider.GEMINI: GeminiProvider,
        LLMProvider.OPENAI: OpenAIProvider,
        LLMProvider.ANTHROPIC: AnthropicProvider
    }
    
    provider_class = provider_classes.get(provider)
    if not provider_class:
        raise ValueError(f"Provider {provider.value} not implemented")
    
    # Default models if not specified
    default_models = {
        LLMProvider.GEMINI: "gemini-2.0-flash",
        LLMProvider.OPENAI: "gpt-4-turbo-preview",
        LLMProvider.ANTHROPIC: "claude-3-opus-20240229"
    }
    
    if not model:
        model = default_models.get(provider)
    
    logger.info(f"Creating LLM provider", provider=provider.value, model=model)
    return provider_class(api_key=api_key, model=model, **kwargs)