"""
File handling utilities for the pipeline.
Provides tools for temporary file management and text processing.
"""
import os
import tempfile
from typing import List, Dict, Optional, Tuple
import logging

logger = logging.getLogger(__name__)


def text_to_temp_file(text: str) -> str:
    """
    Save text to a temporary file and return the file path.
    
    Args:
        text: The text content to save
        
    Returns:
        The path to the temporary file
    """
    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt') as f:
        f.write(text)
        logger.info(f"Created temporary file: {f.name}")
        return f.name


def cleanup_temp_file(file_path: str) -> bool:
    """
    Remove a temporary file.
    
    Args:
        file_path: Path to the file to remove
        
    Returns:
        True if successful, False otherwise
    """
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
            logger.info(f"Cleaned up temporary file: {file_path}")
            return True
        else:
            logger.warning(f"File not found for cleanup: {file_path}")
            return False
    except Exception as e:
        logger.error(f"Error cleaning up file {file_path}: {e}")
        return False


def extract_first_lines(file_path: str, num_lines: int = 20) -> str:
    """
    Extract the first N lines from a file.
    
    Args:
        file_path: Path to the file
        num_lines: Number of lines to extract
        
    Returns:
        The extracted lines as a string
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = []
            for i, line in enumerate(f):
                if i >= num_lines:
                    break
                lines.append(line.rstrip())
            return '\n'.join(lines)
    except Exception as e:
        logger.error(f"Error reading file {file_path}: {e}")
        return ""


class LineTracker:
    """Tracks processed lines to avoid duplicates."""
    
    def __init__(self):
        self.processed_lines = set()
    
    def is_processed(self, start_line: int, end_line: int) -> bool:
        """Check if a line range has been processed."""
        range_key = (start_line, end_line)
        return range_key in self.processed_lines
    
    def mark_processed(self, start_line: int, end_line: int):
        """Mark a line range as processed."""
        range_key = (start_line, end_line)
        self.processed_lines.add(range_key)
    
    def get_unprocessed_ranges(self, matches: List[Dict]) -> List[Dict]:
        """Filter matches to only unprocessed line ranges."""
        unprocessed = []
        for match in matches:
            if 'line_number' in match:
                # Create a range around the match
                start = max(0, match['line_number'] - 10)
                end = match['line_number'] + 10
                
                if not self.is_processed(start, end):
                    self.mark_processed(start, end)
                    unprocessed.append(match)
        
        return unprocessed